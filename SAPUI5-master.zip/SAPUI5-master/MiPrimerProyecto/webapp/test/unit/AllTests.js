sap.ui.define([
	"com/logalifiori/MiPrimerProyecto/test/unit/controller/View1.controller"
], function () {
	"use strict";
});